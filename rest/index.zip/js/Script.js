document.addEventListener("DOMContentLoaded", function () {
    // Cookie Consent Elements
    const cookieBanner = document.getElementById("cookie-banner");
    const acceptBtn = document.getElementById("accept-cookies");
    const rejectBtn = document.getElementById("reject-cookies");

    // Check if the user already made a choice
    if (localStorage.getItem("cookieConsent")) {
        cookieBanner.classList.add("hidden");
    }

    // Accept Cookies
    acceptBtn.addEventListener("click", function () {
        localStorage.setItem("cookieConsent", "accepted");
        cookieBanner.classList.add("hidden");
    });

    // Reject Cookies
    rejectBtn.addEventListener("click", function () {
        localStorage.setItem("cookieConsent", "rejected");
        cookieBanner.classList.add("hidden");
    });

    // Mobile Menu Toggle (If You Plan to Add a Menu Button)
    const menuIcon = document.getElementById("menu-icon");
    const navbar = document.querySelector(".navbar");

    if (menuIcon) {
        menuIcon.addEventListener("click", function () {
            navbar.classList.toggle("active");
        });
    }
});